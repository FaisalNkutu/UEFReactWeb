export type Agent={id:string;name:string;type:'north'|'aicore';endpoint?:string;commands?:string[];raw?:Record<string,unknown>};
export type Turn={role:'user'|'assistant';content:string;agentId?:string;name?:string;time?:string};
export type SharedContext={userContext:string;taskContext:string;systemInstructions:string;conversationHistory:Turn[];agentResults:unknown[]};
export function normalizePythonAgents(payload:any):Agent[]{return (Array.isArray(payload?.agents)?payload.agents:[]).filter((a:any)=>typeof a.id==='string'&&a.id.trim()).map((a:any)=>({id:a.id,name:a.name||a.id,type:(a.type||'north').toLowerCase()==='aicore'?'aicore':'north',endpoint:a.endpoint,raw:a}));}
export function normalizeCoreAgents(payload:any):Agent[]{
 if(Array.isArray(payload?.agents))return payload.agents.map((a:any)=>({id:String(a.id||a.name),name:String(a.name||a.id),type:'aicore' as const,endpoint:a.endpoint||a.url||'',commands:a.commands||[]})).filter((a:Agent)=>a.id);
 const commands=payload?.commandList||payload?.commandData||{};const urls=payload?.agentURLs||{};
 return [...new Set([...Object.keys(commands),...Object.keys(urls)])].map(id=>({id,name:Array.isArray(commands[id])&&commands[id][0]?commands[id][0]:id,type:'aicore' as const,endpoint:urls[id]||'',commands:commands[id]||[]}));
}
function parts(node:any):string{return (Array.isArray(node)?node:[]).map((p:any)=>p?.text||p?.root?.text||'').filter(Boolean).join('\n');}
export function extractText(node:any):string{
 if(!node||typeof node!=='object')return '';
 if(typeof node==='string')return node;
 const direct=parts(node.parts);const artifacts=(Array.isArray(node.artifacts)?node.artifacts:[]).map((a:any)=>parts(a.parts)).filter(Boolean).join('\n');
 return [direct,artifacts,parts(node.status?.message?.parts)].filter(Boolean).join('\n').trim();
}
export function consumeA2AEvent(raw:string,current:string):string{
 if(!raw.trim()||raw.trim()==='[DONE]')return current;
 const event=JSON.parse(raw);
 if(event.error)throw new Error(typeof event.error==='string'?event.error:JSON.stringify(event.error));
 const result=event.result||event;
 if(result.artifactUpdate){const update=result.artifactUpdate;const chunk=parts(update.artifact?.parts);return update.append?current+chunk:chunk;}
 if(result.statusUpdate||result.task)return current;
 return current||extractText(result);
}
export async function readA2AResponse(response:Response,onChunk:(s:string)=>void):Promise<string>{
 if(!response.ok)throw new Error(`A2A HTTP ${response.status}: ${await response.text()}`);
 if(!response.body)throw new Error('Missing A2A response body');
 const reader=response.body.getReader();const decoder=new TextDecoder();let buffer='';let result='';let sawSSE=false;
 const parseBlock=(block:string)=>{const data=block.split(/\r?\n/).filter(line=>line.startsWith('data:')).map(line=>line.slice(5).trimStart()).join('\n');if(!data)return;result=consumeA2AEvent(data,result);onChunk(result);};
 while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});if(buffer.includes('data:'))sawSSE=true;let end;while(sawSSE&&(end=buffer.search(/\r?\n\r?\n/))>=0){const block=buffer.slice(0,end);const separator=buffer.slice(end).match(/^\r?\n\r?\n/)![0];buffer=buffer.slice(end+separator.length);parseBlock(block);}}
 buffer+=decoder.decode();if(sawSSE){if(buffer.trim())parseBlock(buffer);}else if(buffer.trim()){result=consumeA2AEvent(buffer,result);onChunk(result);}
 return result.trim();
}
export function coreText(payload:any):string{
 if(payload?.error)throw new Error(JSON.stringify(payload.error));
 for(const key of ['answer','response','text','message'])if(typeof payload?.[key]==='string'&&payload[key].trim())return payload[key];
 return extractText(payload?.result||payload)||JSON.stringify(payload,null,2);
}
export function a2aRequest(id:string,prompt:string,contextId:string,context:SharedContext){return {jsonrpc:'2.0',id:crypto.randomUUID(),method:'SendStreamingMessage',params:{message:{messageId:crypto.randomUUID(),role:'ROLE_USER',contextId,parts:[{text:prompt}],metadata:{agent_id:id,context}}}};}
