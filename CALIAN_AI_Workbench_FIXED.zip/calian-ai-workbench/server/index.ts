import 'dotenv/config';
import express from 'express';
import { Readable } from 'node:stream';

const app = express();
app.use(express.json({limit:'1mb'}));
const PORT = Number(process.env.PORT || 8787);
const PYTHON_SERVICE_URL = process.env.PYTHON_SERVICE_URL || 'http://127.0.0.1:9999';
const AI_CORE_REGISTRY_URL = process.env.AI_CORE_REGISTRY_URL || '';
const PARADIGM_BRIDGE_TOKEN = process.env.PARADIGM_BRIDGE_TOKEN || '';
let paradigmSnapshot: {commandList: Record<string,string[]>;agentURLs:Record<string,string>} | null = null;
// Explicitly configured upstreams only; the browser cannot supply arbitrary target URLs.
const allowed = new Set([PYTHON_SERVICE_URL,AI_CORE_REGISTRY_URL,...(process.env.AI_CORE_ENDPOINTS || '').split(',')].filter(Boolean).map(s=>s.replace(/\/+$/,'')));
function validate(urlText:string) {
 const u = new URL(urlText);
 if (!['http:','https:'].includes(u.protocol) || u.username || u.password || u.hash) throw new Error('Invalid upstream URL');
 if (![...allowed].some(base => { const b=new URL(base); return u.origin===b.origin && (u.pathname===b.pathname || (base===PYTHON_SERVICE_URL && ['/','/agents','/router/select'].includes(u.pathname))); })) throw new Error('Upstream not allowlisted');
 // No user-supplied upstreams, preventing arbitrary proxy access.
 return u;
}
async function forward(url:string,method:'GET'|'POST',payload?:unknown,stream=false){
 const target=validate(url);
 const response=await fetch(target,{method,headers:{Accept:stream?'text/event-stream, application/json':'application/json',...(method==='POST'?{'Content-Type':'application/json'}:{}),...(stream?{'A2A-Version':'1.0'}:{})},body:method==='POST'?JSON.stringify(payload):undefined,signal:AbortSignal.timeout(180000)});
 return response;
}
async function relay(res:express.Response,upstream:Response){
 res.status(upstream.status);
 res.setHeader('Content-Type',upstream.headers.get('content-type') || 'application/json');
 res.setHeader('Cache-Control','no-cache, no-transform');
 res.setHeader('X-Content-Type-Options','nosniff');
 if(!upstream.body){res.end();return;}
 const stream=Readable.fromWeb(upstream.body as any);
 stream.on('error',()=>res.end());
 stream.pipe(res);
}
const fail=(res:express.Response,e:unknown)=>res.status(502).json({error:e instanceof Error?e.message:String(e)});
app.get('/api/health',(_req,res)=>res.json({status:'ready',pythonService:PYTHON_SERVICE_URL,aiCoreConfigured:Boolean(AI_CORE_REGISTRY_URL)}));
app.get('/api/agents',async(_req,res)=>{try{await relay(res,await forward(PYTHON_SERVICE_URL.replace(/\/+$/,'')+'/agents','GET'));}catch(e){fail(res,e);}});
app.post('/api/paradigm/discovery',(req,res)=>{
 if (!PARADIGM_BRIDGE_TOKEN || req.get('X-Paradigm-Bridge-Token') !== PARADIGM_BRIDGE_TOKEN) {res.status(403).json({error:'Paradigm bridge token required'});return;}
 const {commandList,agentURLs}=req.body||{};
 if (!commandList || typeof commandList!=='object' || Array.isArray(commandList) || !agentURLs || typeof agentURLs!=='object' || Array.isArray(agentURLs)) {res.status(400).json({error:'Expected commandList and agentURLs objects'});return;}
 const safeCommands:Record<string,string[]>={}; const safeURLs:Record<string,string>={};
 for(const [id,values] of Object.entries(commandList)){if(id && Array.isArray(values))safeCommands[id]=values.filter((v):v is string=>typeof v==='string');}
 for(const [id,url] of Object.entries(agentURLs)){if(id && typeof url==='string')safeURLs[id]=url;}
 paradigmSnapshot={commandList:safeCommands,agentURLs:safeURLs};
 res.json({ok:true,count:new Set([...Object.keys(safeCommands),...Object.keys(safeURLs)]).size});
});
app.get('/api/ai-core/agents',async(_req,res)=>{if(paradigmSnapshot){res.json(paradigmSnapshot);return;}if(!AI_CORE_REGISTRY_URL){res.json({agents:[],source:'unconfigured',message:'Waiting for Paradigm discovery callback'});return;}try{await relay(res,await forward(AI_CORE_REGISTRY_URL,'GET'));}catch(e){fail(res,e);}});
app.post('/api/router/select',async(req,res)=>{try{await relay(res,await forward(PYTHON_SERVICE_URL.replace(/\/+$/,'')+'/router/select','POST',req.body));}catch(e){fail(res,e);}});
app.post('/api/a2a',async(req,res)=>{try{await relay(res,await forward(PYTHON_SERVICE_URL.replace(/\/+$/,'')+'/','POST',req.body,true));}catch(e){fail(res,e);}});
app.post('/api/ai-core/execute',async(req,res)=>{
 const {agentId,message,contextId,context}=req.body || {};
 if(typeof agentId!=='string'||typeof message!=='string'||typeof contextId!=='string'){res.status(400).json({error:'Invalid request'});return;}
 // Client does not control destination. Registry endpoints must be explicitly allowlisted.
 const map=Object.fromEntries((process.env.AI_CORE_AGENT_ENDPOINT_MAP||'').split(',').filter(Boolean).map(x=>{const i=x.indexOf('=');return [x.slice(0,i),x.slice(i+1)];}));
 const endpoint=map[agentId];
 if(!endpoint){res.status(400).json({error:'AI Core agent endpoint not configured on server'});return;}
 try{await relay(res,await forward(endpoint,'POST',{message,contextId,context}));}catch(e){fail(res,e);}
});
app.listen(PORT,'127.0.0.1',()=>console.log(`CALIAN proxy: http://127.0.0.1:${PORT}`));
