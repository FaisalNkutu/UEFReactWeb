# CALIAN AI REACT UI

**Architecture, installation, and test guide**  
React + TypeScript + Vite frontend with a local Node.js/Express backend, Python/A2A discovery, AI Core/Paradigm discovery, and metadata-based intelligent agent selection.

> **Verified milestone (26 October 2026):** The UI displayed **7 discovered agents** (1 Python/A2A + 6 AI Core/Paradigm), and **selection-only mode** selected `translation-agent` with **75% confidence** for “Translate Good Morning into French.” This verifies agent discovery and routing for that test, **not execution of the selected agent**. Agent counts and confidence can change with your running services and registry metadata.

## 1. Architecture

```mermaid
flowchart TD
  User[User] --> UI[CALIAN AI REACT UI<br/>React / TypeScript / Vite<br/>127.0.0.1:5173]
  UI -->|/api requests via Vite proxy| API[Node.js / Express<br/>127.0.0.1:8787]
  API -->|GET /agents| PY[Python FastAPI AI Service<br/>127.0.0.1:9999]
  API -->|GET /api/ai-core/agents| CORE[Java AI Core Registry<br/>127.0.0.1:9801]
  SWING[VCCI / Paradigm callback<br/>AISGetCommandsRequest] -.->|optional authenticated discovery publish| API
  API --> REG[Unified discovered agent metadata]
  PY --> REG
  CORE --> REG
  UI -->|POST /api/router/select| API
  API --> ROUTER[Node.js metadata-based routing<br/>trusted discovered agents]
  REG --> ROUTER
  ROUTER -->|selected agent / confidence / reason| UI
  UI -.->|execution only when test-only is unchecked| API
  API -.->|/api/a2a| PY
  API -.->|/api/ai-core/execute| AGENTS[AI Core agent endpoints<br/>requires working execution configuration]
```

**Important implementation detail:** `/api/router/select` is handled by the **Node.js backend in `server/index.ts`**, which ranks trusted discovered agent metadata. It is **not** a proxy to Python `/router/select`. The existing Python `router_api.py` and `router_models.py` are not modified or packaged here. The Python service is used for discovery and A2A execution. The UI is independent of Swing, though it can optionally accept a registry snapshot published by a Paradigm callback.

### Component map

| Component | File / service | Purpose |
|---|---|---|
| Frontend | `src/main.tsx` | UI, discovery refresh, session context, auto/manual selection, selection-only checkbox |
| Agent protocol | `src/protocol.ts` | Normalize discovered agents and parse A2A responses |
| Backend | `server/index.ts` | Same-origin API proxy, trusted metadata router, optional Paradigm bridge, execution forwarding |
| Python/A2A | `PYTHON_SERVICE_URL` (default port 9999) | `GET /agents` and A2A service |
| AI Core/Paradigm | `AI_CORE_REGISTRY_URL` (default port 9801) | Six-agent registry when available |
| Optional bridge | `POST /api/paradigm/discovery` | Receives command list and agent URLs from existing Java callback |
| Frontend dev server | Vite port 5173 | Serves React UI and proxies `/api` to 8787 |

### Agent selection sequence

```mermaid
sequenceDiagram
  actor User
  participant UI as React UI :5173
  participant Node as Express :8787
  participant Python as Python :9999
  participant Core as AI Core :9801
  User->>UI: Translate Good Morning into French
  UI->>Node: POST /api/router/select (message + discovered candidates)
  Node->>Python: GET /agents
  Node->>Core: GET /api/ai-core/agents
  Python-->>Node: Python agent metadata
  Core-->>Node: AI Core agent metadata
  Node->>Node: Match candidates against trusted registry and score metadata
  Node-->>UI: translation-agent, confidence, reason
  alt Test auto-selection only = ON
    UI-->>User: Show selection result; DO NOT execute
  else Test auto-selection only = OFF
    UI->>Node: Execute selected agent
    Note over Node: Execution depends on configured and running agent endpoint
  end
```

## 2. Prerequisites

- Windows PowerShell, **Node.js 20+**, and npm.
- Existing Python AI service at `http://127.0.0.1:9999` for Python agent discovery.
- Existing Java AI Core registry at `http://127.0.0.1:9801/api/ai-core/agents` for AI Core agent discovery, **or** an existing Paradigm callback publishing the registry snapshot.
- For **selection-only** testing, individual AI agent execution endpoints **do not need to be running**.

## 3. Install and start (Windows PowerShell)

1. Extract `CALIAN_AI_REACT_UI.zip` to a convenient folder.
2. Open **PowerShell in the extracted `calian-ai-react-ui` folder** (the folder containing `package.json`).
3. Install dependencies **once**:

   ```powershell
   npm install
   ```

   **Use `npm install`, not `npm run install`.** If PowerShell says `vite is not recognized`, run `npm install` successfully before starting the client.

4. Optional: configure `.env` by copying `.env.example`; the defaults already point to ports **9999**, **9801**, and **8787**. The backend reads environment variables through `dotenv` (see `server/index.ts`).
5. Start both backend and frontend:

   ```powershell
   npm run dev
   ```

   Or use **two PowerShell windows** in the same project directory:

   ```powershell
   npm run dev:server
   ```

   ```powershell
   npm run dev:client
   ```

6. Open `http://127.0.0.1:5173` in a browser.

> Do not start only `npm run dev:client` if you need agent routing: the Express API backend must also be running on port 8787.

## 4. Test the backend and discovery (no agent execution)

With the backend running, open a **new PowerShell window** and run these **one-line commands** separately:

**Backend health:**

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/health' | ConvertTo-Json -Depth 10
```

**Python agent discovery:**

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/agents' | ConvertTo-Json -Depth 10
```

**AI Core agent discovery:**

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/ai-core/agents' | ConvertTo-Json -Depth 10
```

Expected in the verified setup: **1 Python/A2A agent + 6 AI Core/Paradigm agents = 7 total**. If a source is unavailable, check the corresponding service or bridge; don't substitute a hardcoded frontend agent list.

## 5. Test intelligent auto-selection in the UI (recommended)

1. Open `http://127.0.0.1:5173`.
2. Click the **refresh** icon beside **Agent Registry** and confirm the available agent count.
3. Choose **Intelligent Auto Select** from the left sidebar.
4. Keep **“Test auto-selection only (do not execute agent)” CHECKED**.
5. Type **`Translate Good Morning into French`** and click **Send**.
6. Inspect the conversation result and notification banner.

**Expected outcome for the verified registry:**

```text
Auto-selected: translation-agent (75% confidence)
Source: AI Core / Paradigm
Reason: Selected using trusted agent metadata
Selection only — agent execution was not attempted.
```

The UI should also show a routing-success notification. The confidence and reason are generated by the running router; exact text may vary. **No translation response is expected** in this mode, because the purpose is to test *selection*, not execution.

**Optional additional selection-only prompts:**

| Prompt | Expected agent (if registry metadata matches) |
|---|---|
| `Roll two dice` | Dice Agent |
| `Query a database table` | DBAgent |
| `Generate a social media post` | Social Media Posts Generation Agent |
| `Transcribe this audio` | SpeechAgent |
| `Format this as structured JSON` | structuredtext-agent |

These are routing expectations, not proof of the individual agents' availability or execution.

## 6. Test routing directly with PowerShell (no agent execution)

This hits the **Node.js routing endpoint**, using the backend's trusted discovery registry:

```powershell
Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/router/select' -Method POST -ContentType 'application/json' -Body (@{message='Translate Good Morning into French'; agents=@(@{id='translation-agent';type='aicore'})} | ConvertTo-Json -Depth 10) | ConvertTo-Json -Depth 10
```

Expected fields include `agent.id`, `agent.type`, `confidence`, `reason`, and `method`. This test does **not** call an execution endpoint. The listed candidate must exist in the **server-discovered** registry; otherwise the router will reject it. The response can differ from the UI test if you supply a different candidate list.

## 7. Tests and build

```powershell
npm test
npm run build
```

`npm test` runs TypeScript protocol tests. `npm run build` type-checks and builds the React frontend. These commands are not substitutes for the live discovery/routing tests above.

## 8. Optional Paradigm discovery bridge

The Java Swing/Paradigm callback can publish `commandList` and `agentURLs` to `POST /api/paradigm/discovery` when both sides share a nonempty `PARADIGM_BRIDGE_TOKEN`. The backend stores the latest snapshot in memory and can serve it through `GET /api/ai-core/agents` if the configured AI Core HTTP registry is unavailable. See `legacy-reference/ParadigmReactPublisher.java` and the existing callback integration notes in that file. This bridge is **optional** when your AI Core HTTP registry already returns the agents. Restarting the backend clears the in-memory snapshot.

## 9. Execution: separate, not yet verified

Unchecking **Test auto-selection only** permits the UI to call `/api/a2a` for Python agents or `/api/ai-core/execute` for AI Core agents. This requires actual running endpoints and appropriate backend configuration. A successful **selection-only** test does not prove agent execution. Preserve the working routing test while developing execution separately.

## 10. Troubleshooting

| Symptom | Check |
|---|---|
| `'vite' is not recognized` | Run `npm install` in the folder containing `package.json`. |
| `npm error Missing script: install` | Use `npm install`, **not** `npm run install`. |
| UI loads but requests fail | Run `npm run dev` (both servers), not only `npm run dev:client`. |
| Python agents missing | Confirm the Python service on port 9999 and test `/api/agents`. |
| AI Core agents missing | Confirm port 9801 registry or refresh the Paradigm discovery bridge. |
| Auto-selection returns no match | Refresh discovery and verify the candidate agent metadata and message. |
| `fetch failed` after a routing result | Check whether selection-only is checked; execution may have been attempted. |
| `No agent capability matched` | Try a prompt containing a capability represented in the discovered metadata. |

## 11. Project layout

```text
calian-ai-react-ui/
├── README.md
├── package.json
├── .env.example
├── index.html
├── vite.config.ts
├── server/
│   └── index.ts
├── src/
│   ├── main.tsx
│   ├── protocol.ts
│   └── styles.css
├── tests/
│   └── protocol.test.ts
└── legacy-reference/
    └── ... original Java reference files
```

## 12. Security and boundaries

The Express API listens on `127.0.0.1`; it is intended for local development. Do not expose it to the public internet without authentication, authorization, TLS, auditing, and rate limiting. The optional Paradigm discovery publisher uses a shared token. The frontend does not invoke Paradigm's Java callbacks directly. Session context/history is held in the browser and can be exported as JSON; no persistent database is claimed.

**Project name:** CALIAN AI REACT UI. **Focus of the verified test:** intelligent agent discovery and auto-selection, not execution.
