import test from 'node:test';
import assert from 'node:assert/strict';
import {routerCandidates,resolveRoutedAgent,type Agent} from '../src/protocol';
const agents:Agent[]=[
 {id:'python-uuid',name:"Faisal's agent",type:'north',raw:{id:'python-uuid',name:"Faisal's agent"}},
 {id:'translation-agent',name:'translation-agent',type:'aicore',endpoint:'http://127.0.0.1:15048/translate'},
 {id:'Dice Agent',name:'Dice Agent',type:'aicore',endpoint:'http://localhost:11000'}
];
test('router receives all seven-style mixed registry agents',()=>{const result=routerCandidates(agents);assert.equal(result.length,3);assert.equal(result[1].id,'translation-agent');assert.equal(result[1].endpoint,'http://127.0.0.1:15048/translate');});
test('router choice resolves to original AI Core agent with endpoint',()=>{assert.equal(resolveRoutedAgent(agents,{id:'translation-agent'})?.endpoint,'http://127.0.0.1:15048/translate');});
test('unknown routed agent is rejected',()=>{assert.equal(resolveRoutedAgent(agents,{id:'unknown'}),undefined);});
test('router choice can match unique friendly name',()=>{assert.equal(resolveRoutedAgent(agents,{name:'dice agent'})?.id,'Dice Agent');});
