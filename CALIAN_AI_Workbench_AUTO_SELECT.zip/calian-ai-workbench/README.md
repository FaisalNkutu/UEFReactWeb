# CALIAN AI Workbench

-grade React/TypeScript replacement for the standalone Swing ChatApp. The `legacy-reference/` directory contains the original seven Java classes and `pom.xml` unchanged for comparison.

## Requirements

- Node.js 20+ and npm
- Existing Python AI Service running at `http://127.0.0.1:9999`
- Optional Java 21 AI Core/Paradigm environment and registry endpoint

## Quick start (Windows PowerShell)

```powershell
cd calian-ai-workbench
npm install
Copy-Item .env.example .env
npm run dev
```

Open **http://127.0.0.1:5173**. The Vite frontend runs on port 5173 and the same-origin Express backend proxy runs on 8787. The backend connects to the existing Python service on 9999. Configure `.env` as needed; restart `npm run dev` after changing it. Environment variables can be loaded from `.env` using your shell or `node --env-file=.env` for production; development server reads process environment, so for PowerShell set `$env:PYTHON_SERVICE_URL=...` before launching if different from default. `npm run build` validates TypeScript and builds the frontend; `npm test` runs protocol tests.

## Compatibility mapping

| Swing implementation | React implementation |
| --- | --- |
| `ChatApp.refreshAgents()` | `refresh()` + `/api/agents` |
| `AICoreHttpDiscovery` | `/api/ai-core/agents` + `normalizeCoreAgents()` |
| `ParadigmAgentDiscovery` | normalization of commandList/commandData + agentURLs |
| `ChatApp.context()` | `sharedContext()` (last 12 turns) |
| `ChatApp.submit()` | `send()` with auto/manual agent selection |
| `/router/select` | `/api/router/select` backend proxy |
| `SendStreamingMessage` | `/api/a2a`, `A2A-Version: 1.0`, streaming parser |
| `sendAICore()` | `/api/ai-core/execute` with explicit endpoint mapping |
| `New Chat` | New Session, UUID regeneration and history reset |

## AI Core / Paradigm limitations

The browser **cannot execute Paradigm's Java `IFRREnabled` callbacks**. The original `ChatAgentResponseHandler` and `AISGetCommandsRequest` require a running Java adapter that exposes the discovered `commandList` and `agentURLs` through HTTP JSON. If you have such a registry, set `AI_CORE_REGISTRY_URL` to its full endpoint. Direct AI Core execution requires server-side `AI_CORE_AGENT_ENDPOINT_MAP` (e.g. `translation-agent=http://127.0.0.1:15048/translate`) and the same URLs in `AI_CORE_ENDPOINTS`; never use user-controlled arbitrary endpoint URLs. If the registry is not available, Python agents still work. The existing `ChatUIDelegate` throws `UnsupportedOperationException` and is not a functional bridge.

## Security and reproducibility

- Browser communicates only with the local same-origin proxy; upstream destinations are explicitly configured server-side.
- No authentication is implemented; bind the proxy to localhost, and **do not expose it publicly** without authentication, authorization, rate limits, TLS, auditing, and stronger upstream validation.
- Session history is held in memory and exported to JSON on demand. The original Swing application also holds session history in memory. No PostgreSQL persistence is claimed.
- Context is included in both routing and execution requests, with user/task/system fields and up to 12 prior turns. The server does not log message bodies.
- A2A streaming parser supports v1.0 artifact updates and append/replace semantics, ignores status-only events, and handles non-streaming JSON.
- Route selection is restricted to Python agents, as in the original Swing implementation. AI Core agents can be selected manually.
- Automated tests cover discovery and stream parsing. End-to-end testing against your running services remains necessary.

## Build commands

```bash
npm install
npm test
npm run build
npm run dev
```

## Recommended next integration

Add a small Java 21 HTTP bridge in your Maven project that listens for `AISGetCommandsRequest` and returns the exact JSON fields consumed by this React project. Preserve the private Calian Paradigm Maven dependencies in the Java project, not in the browser bundle.

## Paradigm AI Service discovery bridge (v1.1)

The Java Paradigm `AISGetCommandsRequest` callback is the source of truth for AI Core agent discovery. The React server now accepts its `commandList` and `agentURLs` at `POST /api/paradigm/discovery`, and exposes the latest snapshot at `GET /api/ai-core/agents`. Python discovery is retained for the existing Python/A2A agent only. **This change fixes discovery, not AI Core execution or automatic routing of Paradigm agents.**

1. Set the **same** nonempty `PARADIGM_BRIDGE_TOKEN` environment variable in the PowerShell sessions starting React and Swing. For local testing: `$env:PARADIGM_BRIDGE_TOKEN='replace-with-a-long-random-secret'` (do not commit your real token).
2. In your Java Swing project, copy `legacy-reference/ParadigmReactPublisher.java` to `src/main/java/com/calian/chat/ParadigmReactPublisher.java`.
3. In the Swing project's existing `ChatAgentResponseHandler.java`, inside the `AISGetCommandsRequest result` block immediately after `app.acceptParadigmAgents(...)`, add: `ParadigmReactPublisher.publish(result.getCommandList(), result.getAgentURLs());` (the patched reference file demonstrates this).
4. Restart React using `npm run dev`; restart Swing and click **Refresh Agents** to trigger a fresh Paradigm callback; then click the React registry refresh icon. The React AI Core counter should reflect the received Paradigm agents.
5. If Java prints `Paradigm React discovery publish failed`, inspect the local server log. The bridge binds to `127.0.0.1:8787`, accepts a shared token and stores a snapshot in memory (not persistent). If React restarts, refresh Swing discovery again.

The bridge does not fabricate missing execution endpoints. The existing `AI_CORE_AGENT_ENDPOINT_MAP` mechanism remains separate; native Paradigm execution still needs a dedicated adapter.


## CALIAN naming migration
All previous branding, including legacy Java package and Maven groupId, has been changed to CALIAN. If integrating the Java bridge into an existing project still using the previous Java package, either move the Java classes into `com.calian.chat` or adapt the package declarations to match your existing project.
\n## Intelligent Auto Select\n\nAuto Select now passes **all** discovered Python/A2A and AI Core/Paradigm agents to the existing Python `/router/select` service, preserving `message`, `contextId`, `previousAgentId`, and shared context. The selected ID is resolved against the local registry, then dispatched through the existing Python or AI Core execution path. No new Java services are required. Note: AI Core execution still requires `AI_CORE_AGENT_ENDPOINT_MAP` configuration and the endpoint's expected request protocol; routing alone does not configure execution.\n