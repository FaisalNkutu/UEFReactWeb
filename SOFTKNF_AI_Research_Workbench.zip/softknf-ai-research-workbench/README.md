# SOFTKNF AI Research Workbench

Research-grade React/TypeScript replacement for the standalone Swing ChatApp. The `legacy-reference/` directory contains the original seven Java classes and `pom.xml` unchanged for comparison.

## Requirements

- Node.js 20+ and npm
- Existing Python AI Service running at `http://127.0.0.1:9999`
- Optional Java 21 AI Core/Paradigm environment and registry endpoint

## Quick start (Windows PowerShell)

```powershell
cd softknf-ai-research-workbench
npm install
Copy-Item .env.example .env
npm run dev
```

Open **http://127.0.0.1:5173**. The Vite frontend runs on port 5173 and the same-origin Express backend proxy runs on 8787. The backend connects to the existing Python service on 9999. Configure `.env` as needed; restart `npm run dev` after changing it. Environment variables can be loaded from `.env` using your shell or `node --env-file=.env` for production; development server reads process environment, so for PowerShell set `$env:PYTHON_SERVICE_URL=...` before launching if different from default. `npm run build` validates TypeScript and builds the frontend; `npm test` runs protocol tests.

## Compatibility mapping

| Swing implementation | React implementation |
| --- | --- |
| `ChatApp.refreshAgents()` | `refresh()` + `/api/agents` |
| `AICoreHttpDiscovery` | `/api/ai-core/agents` + `normalizeCoreAgents()` |
| `ParadigmAgentDiscovery` | normalization of commandList/commandData + agentURLs |
| `ChatApp.context()` | `sharedContext()` (last 12 turns) |
| `ChatApp.submit()` | `send()` with auto/manual agent selection |
| `/router/select` | `/api/router/select` backend proxy |
| `SendStreamingMessage` | `/api/a2a`, `A2A-Version: 1.0`, streaming parser |
| `sendAICore()` | `/api/ai-core/execute` with explicit endpoint mapping |
| `New Chat` | New Session, UUID regeneration and history reset |

## AI Core / Paradigm limitations

The browser **cannot execute Paradigm's Java `IFRREnabled` callbacks**. The original `ChatAgentResponseHandler` and `AISGetCommandsRequest` require a running Java adapter that exposes the discovered `commandList` and `agentURLs` through HTTP JSON. If you have such a registry, set `AI_CORE_REGISTRY_URL` to its full endpoint. Direct AI Core execution requires server-side `AI_CORE_AGENT_ENDPOINT_MAP` (e.g. `translation-agent=http://127.0.0.1:15048/translate`) and the same URLs in `AI_CORE_ENDPOINTS`; never use user-controlled arbitrary endpoint URLs. If the registry is not available, Python agents still work. The existing `ChatUIDelegate` throws `UnsupportedOperationException` and is not a functional bridge.

## Security and research reproducibility

- Browser communicates only with the local same-origin proxy; upstream destinations are explicitly configured server-side.
- No authentication is implemented; bind the proxy to localhost, and **do not expose it publicly** without authentication, authorization, rate limits, TLS, auditing, and stronger upstream validation.
- Session history is held in memory and exported to JSON on demand. The original Swing application also holds session history in memory. No PostgreSQL persistence is claimed.
- Context is included in both routing and execution requests, with user/task/system fields and up to 12 prior turns. The server does not log message bodies.
- A2A streaming parser supports v1.0 artifact updates and append/replace semantics, ignores status-only events, and handles non-streaming JSON.
- Route selection is restricted to Python agents, as in the original Swing implementation. AI Core agents can be selected manually.
- Automated tests cover discovery and stream parsing. End-to-end testing against your running services remains necessary.

## Build commands

```bash
npm install
npm test
npm run build
npm run dev
```

## Recommended next integration

Add a small Java 21 HTTP bridge in your Maven project that listens for `AISGetCommandsRequest` and returns the exact JSON fields consumed by this React project. Preserve the private Calian Paradigm Maven dependencies in the Java project, not in the browser bundle.
